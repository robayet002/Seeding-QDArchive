"""
db/database.py
Thin wrapper around the SQLite database.
All insert helpers return the new row id.
"""

import sqlite3
import pathlib

DB_NAME = "23277555-seeding.db"
SCHEMA_FILE = pathlib.Path(__file__).parent / "schema.sql"


def get_connection(db_path: str = DB_NAME) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.row_factory = sqlite3.Row
    return conn


def init_db(db_path: str = DB_NAME) -> None:
    """Create tables if they don't exist yet."""
    schema = SCHEMA_FILE.read_text()
    with get_connection(db_path) as conn:
        conn.executescript(schema)
    print(f"[DB] Initialised: {db_path}")


# ── REPOSITORIES ────────────────────────────────────────────────────────────

def upsert_repository(conn: sqlite3.Connection, name: str, url: str) -> int:
    cur = conn.execute("SELECT id FROM REPOSITORIES WHERE url = ?", (url,))
    row = cur.fetchone()
    if row:
        return row["id"]
    cur = conn.execute(
        "INSERT INTO REPOSITORIES (name, url) VALUES (?, ?)", (name, url)
    )
    return cur.lastrowid


# ── PROJECTS ─────────────────────────────────────────────────────────────────

def insert_project(conn: sqlite3.Connection, **kwargs) -> int:
    cols = ", ".join(kwargs.keys())
    placeholders = ", ".join("?" * len(kwargs))
    cur = conn.execute(
        f"INSERT INTO PROJECTS ({cols}) VALUES ({placeholders})",
        list(kwargs.values()),
    )
    return cur.lastrowid


def project_exists(conn: sqlite3.Connection, project_url: str) -> bool:
    cur = conn.execute("SELECT 1 FROM PROJECTS WHERE project_url = ?", (project_url,))
    return cur.fetchone() is not None


# ── FILES ────────────────────────────────────────────────────────────────────

def insert_file(conn: sqlite3.Connection, project_id: int,
                file_name: str, file_type: str, status: str) -> int:
    cur = conn.execute(
        "INSERT INTO FILES (project_id, file_name, file_type, status) VALUES (?, ?, ?, ?)",
        (project_id, file_name, file_type, status),
    )
    return cur.lastrowid


# ── KEYWORDS ─────────────────────────────────────────────────────────────────

def insert_keyword(conn: sqlite3.Connection, project_id: int, keyword: str) -> int:
    cur = conn.execute(
        "INSERT INTO KEYWORDS (project_id, keyword) VALUES (?, ?)",
        (project_id, keyword),
    )
    return cur.lastrowid


# ── PERSON_ROLE ───────────────────────────────────────────────────────────────

def insert_person(conn: sqlite3.Connection, project_id: int,
                  name: str, role: str) -> int:
    cur = conn.execute(
        "INSERT INTO PERSON_ROLE (project_id, name, role) VALUES (?, ?, ?)",
        (project_id, name, role),
    )
    return cur.lastrowid


# ── LICENSES ─────────────────────────────────────────────────────────────────

def insert_license(conn: sqlite3.Connection, project_id: int, license_str: str) -> int:
    cur = conn.execute(
        "INSERT INTO LICENSES (project_id, license) VALUES (?, ?)",
        (project_id, license_str),
    )
    return cur.lastrowid
