"""
main.py
Entry point for the SQ26 QDArchive seeding pipeline.

Usage:
    python main.py                        # run both scrapers
    python main.py --repo datafirst       # run only DataFirst
    python main.py --repo dataverse_no    # run only Dataverse Norway
    python main.py --max-projects 50      # limit for testing
"""

import argparse
import pathlib
import sys

# Ensure the project root is always on sys.path,
# regardless of where Python is launched from.
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))

from db.database import init_db, get_connection
from scrapers import datafirst_scraper, dataverse_no_scraper

DB_PATH   = "23277555-seeding.db"
DATA_ROOT = pathlib.Path("data")


def main():
    parser = argparse.ArgumentParser(description="SQ26 QDArchive seeding pipeline")
    parser.add_argument(
        "--repo",
        choices=["datafirst", "dataverse_no", "all"],
        default="all",
        help="Which repository scraper to run (default: all)",
    )
    parser.add_argument(
        "--max-projects",
        type=int,
        default=500,
        help="Safety cap on number of projects per scraper (default: 500)",
    )
    parser.add_argument(
        "--db",
        default=DB_PATH,
        help=f"Path to SQLite database (default: {DB_PATH})",
    )
    args = parser.parse_args()

    # ── Initialise DB ────────────────────────────────────────────────────────
    init_db(args.db)
    conn = get_connection(args.db)

    DATA_ROOT.mkdir(parents=True, exist_ok=True)

    try:
        if args.repo in ("datafirst", "all"):
            print("\n" + "=" * 60)
            print("SCRAPER: DataFirst UCT")
            print("=" * 60)
            datafirst_scraper.run(
                conn=conn,
                data_root=DATA_ROOT,
                max_projects=args.max_projects,
            )

        if args.repo in ("dataverse_no", "all"):
            print("\n" + "=" * 60)
            print("SCRAPER: Dataverse Norway")
            print("=" * 60)
            dataverse_no_scraper.run(
                conn=conn,
                data_root=DATA_ROOT,
                max_projects=args.max_projects,
            )

    except KeyboardInterrupt:
        print("\n[!] Interrupted by user. Committing and closing DB.")
        conn.commit()
    finally:
        conn.commit()
        conn.close()
        print(f"\n[✓] Database saved: {args.db}")

    # ── Summary stats ────────────────────────────────────────────────────────
    conn2 = get_connection(args.db)
    for table in ["REPOSITORIES", "PROJECTS", "FILES", "KEYWORDS", "PERSON_ROLE", "LICENSES"]:
        count = conn2.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        print(f"  {table:<20} {count:>6} rows")
    conn2.close()


if __name__ == "__main__":
    main()
