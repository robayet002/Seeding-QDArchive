"""
pipeline/downloader.py
Generic HTTP download helper used by all scrapers.
Handles retry logic, size limits and maps HTTP errors to
the professor's DOWNLOAD_RESULT enum values.
"""

import os
import time
import pathlib
import requests
from typing import Tuple

# Files larger than this are skipped (500 MB)
MAX_FILE_SIZE_BYTES = 500 * 1024 * 1024

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (compatible; SQ26-QDArchive-Seeder/1.0; "
        "FAU Erlangen research project)"
    )
}

SESSION = requests.Session()
SESSION.headers.update(HEADERS)


def download_file(
    url: str,
    dest_path: pathlib.Path,
    retries: int = 3,
    timeout: int = 60,
) -> Tuple[str, int]:
    """
    Download *url* to *dest_path*.

    Returns
    -------
    (status, size_bytes)
    status is one of:
        SUCCEEDED
        FAILED_LOGIN_REQUIRED
        FAILED_SERVER_UNRESPONSIVE
        FAILED_TOO_LARGE
    """
    dest_path.parent.mkdir(parents=True, exist_ok=True)

    for attempt in range(1, retries + 1):
        try:
            resp = SESSION.get(url, stream=True, timeout=timeout, allow_redirects=True)

            if resp.status_code in (401, 403):
                return "FAILED_LOGIN_REQUIRED", 0

            if resp.status_code == 404:
                return "FAILED_SERVER_UNRESPONSIVE", 0

            if resp.status_code >= 500:
                if attempt < retries:
                    time.sleep(5 * attempt)
                    continue
                return "FAILED_SERVER_UNRESPONSIVE", 0

            resp.raise_for_status()

            # Check Content-Length header before downloading
            content_length = resp.headers.get("Content-Length")
            if content_length and int(content_length) > MAX_FILE_SIZE_BYTES:
                return "FAILED_TOO_LARGE", int(content_length)

            total = 0
            with open(dest_path, "wb") as fh:
                for chunk in resp.iter_content(chunk_size=65536):
                    if chunk:
                        fh.write(chunk)
                        total += len(chunk)
                        if total > MAX_FILE_SIZE_BYTES:
                            fh.close()
                            os.remove(dest_path)
                            return "FAILED_TOO_LARGE", total

            return "SUCCEEDED", total

        except requests.exceptions.ConnectionError:
            if attempt < retries:
                time.sleep(5 * attempt)
            else:
                return "FAILED_SERVER_UNRESPONSIVE", 0

        except requests.exceptions.Timeout:
            if attempt < retries:
                time.sleep(5 * attempt)
            else:
                return "FAILED_SERVER_UNRESPONSIVE", 0

        except requests.exceptions.RequestException:
            return "FAILED_SERVER_UNRESPONSIVE", 0

    return "FAILED_SERVER_UNRESPONSIVE", 0
