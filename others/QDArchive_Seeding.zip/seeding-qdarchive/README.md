# SQ26 — Seeding QDArchive: Part 1 Data Acquisition

**Student:** 23277555  
**Course:** Seeding QDArchive — FAU Erlangen-Nürnberg, Professorship for Open-Source Software  
**Supervisor:** Prof. Dirk Riehle  
**Semester:** Winter 2025/26 + Summer 2026  

---

## Overview

This repository contains the Part 1 (Data Acquisition) pipeline for the SQ26 Seeding QDArchive project. The goal is to find, download, and catalogue qualitative research data projects from two assigned repositories, storing all metadata in a structured SQLite database.

The database file **`23277555-seeding.db`** is committed at the root of this repository, as required.

---

## Assigned Repositories

| # | Name | URL | Software | Download Method |
|---|------|-----|----------|-----------------|
| 1 | DataFirst UCT | https://www.datafirst.uct.ac.za | NADA (National Data Archive) | API-CALL + SCRAPING |
| 2 | Dataverse Norway | https://dataverse.no | Dataverse | API-CALL |

---

## Repository Structure

```
.
├── 23277555-seeding.db          # SQLite database (professor's submission requirement)
├── main.py                      # Pipeline entry point
├── requirements.txt
├── .gitignore
│
├── db/
│   ├── schema.sql               # All 6 table definitions with CHECK constraints
│   └── database.py              # DB connection + insert helpers
│
├── pipeline/
│   └── downloader.py            # Generic HTTP downloader with retry + status mapping
│
├── scrapers/
│   ├── datafirst_scraper.py     # DataFirst UCT (NADA) scraper
│   └── dataverse_no_scraper.py  # Dataverse Norway API scraper
│
├── export/
│   └── export_csv.py            # Export all tables to CSV
│
└── scripts/
    ├── retry_failed.py          # Re-attempt FAILED_SERVER_UNRESPONSIVE downloads
    └── inspect_db.py            # Print DB statistics summary
```

---

## Database Schema

Six tables as specified in the professor's schema document:

- **REPOSITORIES** — our own list of known repositories (id, name, url)
- **PROJECTS** — one row per research project with all required metadata fields
- **FILES** — all files found per project, with download status
- **KEYWORDS** — one keyword per row (not comma-separated)
- **PERSON_ROLE** — persons with roles: AUTHOR, UPLOADER, OWNER, OTHER, UNKNOWN
- **LICENSES** — license strings per project (CC BY, CC0, ODbL, etc.)

All enums are enforced via SQLite `CHECK` constraints.

---

## Setup and Usage

### 1. Clone and set up environment

```bash
git clone https://github.com/robayet002/Seeding-QDArchive.git
cd Seeding-QDArchive

python -m venv venv
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

pip install -r requirements.txt
```

### 2. Run the full pipeline

```bash
python main.py
```

Run only one repository:
```bash
python main.py --repo datafirst
python main.py --repo dataverse_no
```

Test with a small number of projects first:
```bash
python main.py --max-projects 10
```

### 3. Inspect results

```bash
python scripts/inspect_db.py
```

### 4. Retry failed downloads

```bash
python scripts/retry_failed.py
```

### 5. Export to CSV

```bash
python export/export_csv.py
```

---

## Search Queries Used

### DataFirst UCT
- `qualitative`
- `interview`
- `focus group`
- `qualitative research`
- `qdpx`

### Dataverse Norway
- `qdpx`
- `qualitative research`
- `interview transcripts`
- `focus group`
- `thematic analysis`
- `nvivo`
- `atlas.ti`
- `qualitative data`

---

## Download Method Notes

| Repository | Metadata | Files | Reason |
|------------|----------|-------|--------|
| DataFirst UCT | `API-CALL` | `SCRAPING` | JSON metadata via `/metadata/export/{id}/json`; file URLs discovered by scraping the related-materials HTML page |
| Dataverse Norway | `API-CALL` | `API-CALL` | Full Dataverse REST API; robots.txt prohibits scraping |

---

## File Download Status Values

Per professor's schema:

| Status | Meaning |
|--------|---------|
| `SUCCEEDED` | File downloaded successfully |
| `FAILED_LOGIN_REQUIRED` | HTTP 401/403 or file marked restricted |
| `FAILED_SERVER_UNRESPONSIVE` | Server timeout, connection error, or 5xx |
| `FAILED_TOO_LARGE` | File exceeds 500 MB size limit |

---

## Data Folder

The `data/` folder is **not** committed to GitHub (too large). It is uploaded separately to FAUbox/Google Drive. Structure:

```
data/
├── datafirst/
│   └── {catalog_id}/
│       ├── catalog_{id}_metadata.json
│       └── {filename}.pdf / .docx / ...
└── dataverse_no/
    └── {doi_slug}/
        ├── dataset_metadata.json
        └── {filename}.*
```

---

## Technical Challenges

> Per project requirements: this section discusses **data** challenges encountered (not programming challenges).

### 1. Login walls on microdata (DataFirst UCT)

The majority of DataFirst's datasets require user registration and login before microdata files can be downloaded. Even projects marked "Public use data" in the catalog listing require creating an account and accepting terms of use. The raw data files (`.sav`, `.dta`, `.csv`) are therefore largely inaccessible without authentication, leading to `FAILED_LOGIN_REQUIRED` statuses. Only documentation PDFs, questionnaires, and reports are freely downloadable without login.

**Impact:** Most FILE records for DataFirst projects will have status `FAILED_LOGIN_REQUIRED`. The project metadata (title, description, license, persons, keywords) is fully captured via the JSON API, but the actual research data files cannot be downloaded in bulk.

### 2. Absence of QDA files on DataFirst UCT

DataFirst is primarily a **quantitative** microdata repository for South African surveys (Labour Force Survey, census data, household surveys etc.). Searching for `qdpx`, `qualitative`, or `interview` returns results where those terms appear in the questionnaire variable labels (e.g. a variable named "interview date"), not in the sense of qualitative research projects. True QDA files (`.qdpx`, `.nvp`, `.mx24`) were not found on this platform. The qualitative signal in search results is therefore weak and requires careful post-hoc filtering.

### 3. robots.txt blocks scraping on Dataverse Norway

Dataverse Norway's `robots.txt` disallows all automated crawling of the web interface. This means the standard approach of scraping HTML pages is not permitted. We are entirely dependent on the Dataverse REST API for all data access. While the API is well-documented and works well, it means we cannot discover data through alternative routes (e.g. browsing by collection or subject).

### 4. Inconsistent license data across Dataverse Norway datasets

License information in Dataverse Norway is stored inconsistently across datasets. Some older datasets store the license as a free-text `termsOfUse` field (e.g. "This data is available for download for the following types of users..."), while newer datasets use the structured `license` field with a name like `CC0` or `CC BY 4.0`. In many cases the `termsOfUse` field contains full legal text rather than a short license identifier. Per the professor's instruction ("if there is a different original data string, use this and we'll fix later"), we store the raw string as-is when it does not match a known short form.

### 5. Keyword data quality on DataFirst (NADA)

The NADA platform used by DataFirst does not expose structured keywords through its JSON metadata endpoint. Keywords are embedded in the variable-level metadata (DDI/XML format), not at the dataset level. As a fallback, we extract the `data_kind` field and `nation` entries as keywords. This means DataFirst keyword coverage is sparse and non-specific. A proper keyword extraction would require parsing the full DDI/XML codebook per project.

### 6. Multiple versions of the same dataset

Both repositories allow versioning of datasets. DataFirst uses a version string in the catalog ID (e.g. `zaf-statssa-dts-2021-v1`). Dataverse Norway uses major/minor version numbers. The current pipeline records the **latest published version** only and stores the version string in the `version` field. If a project's version history is needed later (for tracking updates to QDA files), this would require significant additional logic.

### 7. Large file sizes

Several datasets on Dataverse Norway contain large archive files (`.zip` packages of interview transcripts or raw audio). Files exceeding 500 MB are skipped with status `FAILED_TOO_LARGE`. This threshold was chosen as a practical limit for initial seeding; these files can be re-attempted individually using `scripts/retry_failed.py --include-large`.

---

## Submission

- [x] `23277555-seeding.db` committed to repo root
- [x] Git tag `part-1-release` on final commit
- [ ] Data folder uploaded to FAUbox/Google Drive
- [ ] Submission form filled in with GitHub link and data folder link
