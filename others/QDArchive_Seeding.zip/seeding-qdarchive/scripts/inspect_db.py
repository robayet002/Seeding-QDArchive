"""
scripts/inspect_db.py
Print a quick summary of what is in the database.

Usage:
    python scripts/inspect_db.py
    python scripts/inspect_db.py --db 23277555-seeding.db
"""

import argparse
import pathlib
import sqlite3
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from db.database import get_connection

DB_DEFAULT = "23277555-seeding.db"


def inspect(db_path: str) -> None:
    conn = get_connection(db_path)

    print(f"\n{'='*55}")
    print(f"  Database: {db_path}")
    print(f"{'='*55}\n")

    # Row counts
    for table in ["REPOSITORIES", "PROJECTS", "FILES", "KEYWORDS", "PERSON_ROLE", "LICENSES"]:
        count = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        print(f"  {table:<20} {count:>6} rows")

    # File status breakdown
    print("\n  File download status breakdown:")
    rows = conn.execute("""
        SELECT status, COUNT(*) as n FROM FILES GROUP BY status ORDER BY n DESC
    """).fetchall()
    for r in rows:
        print(f"    {r[0]:<35} {r[1]:>5}")

    # Projects per repo
    print("\n  Projects per repository:")
    rows = conn.execute("""
        SELECT r.name, COUNT(p.id) as n
        FROM REPOSITORIES r
        LEFT JOIN PROJECTS p ON p.repository_id = r.id
        GROUP BY r.id
    """).fetchall()
    for r in rows:
        print(f"    {r[0]:<35} {r[1]:>5}")

    # Download method breakdown
    print("\n  Download methods used:")
    rows = conn.execute("""
        SELECT download_method, COUNT(*) as n FROM PROJECTS GROUP BY download_method
    """).fetchall()
    for r in rows:
        print(f"    {r[0]:<20} {r[1]:>5}")

    # License breakdown
    print("\n  Licenses found (top 10):")
    rows = conn.execute("""
        SELECT license, COUNT(*) as n FROM LICENSES GROUP BY license ORDER BY n DESC LIMIT 10
    """).fetchall()
    for r in rows:
        print(f"    {r[0]:<35} {r[1]:>5}")

    print()
    conn.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", default=DB_DEFAULT)
    args = parser.parse_args()
    inspect(args.db)
