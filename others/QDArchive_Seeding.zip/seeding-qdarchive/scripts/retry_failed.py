"""
scripts/retry_failed.py
Re-attempts downloads that previously recorded a non-login failure status.

Only retries:
  FAILED_SERVER_UNRESPONSIVE  — server may have been temporarily down
  FAILED_TOO_LARGE            — (skipped by default; pass --include-large to retry)

Never retries:
  FAILED_LOGIN_REQUIRED       — still requires authentication; won't change

Usage:
    python scripts/retry_failed.py
    python scripts/retry_failed.py --include-large
    python scripts/retry_failed.py --db my_other.db
"""

import argparse
import pathlib
import sqlite3
import sys
import os

# Make sure project root is on the path
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

from db.database import get_connection
from pipeline.downloader import download_file

DB_DEFAULT  = "23277555-seeding.db"
DATA_ROOT   = pathlib.Path("data")


def build_download_url(repo_folder: str, project_folder: str, file_name: str) -> str:
    """
    Reconstruct the original download URL from stored metadata.
    This is repo-specific; we look up the project_url from the PROJECTS table.
    """
    # We can't perfectly reconstruct the original URL from folder names alone,
    # so we return None and let the caller fetch it from the DB join.
    return None


def retry_failed(db_path: str, include_large: bool = False) -> None:
    conn = get_connection(db_path)

    statuses = ["FAILED_SERVER_UNRESPONSIVE"]
    if include_large:
        statuses.append("FAILED_TOO_LARGE")

    placeholders = ",".join("?" * len(statuses))
    rows = conn.execute(f"""
        SELECT
            f.id            AS file_id,
            f.file_name,
            f.file_type,
            f.status,
            p.download_repository_folder,
            p.download_project_folder,
            p.download_version_folder,
            p.project_url,
            p.id            AS project_id
        FROM FILES f
        JOIN PROJECTS p ON p.id = f.project_id
        WHERE f.status IN ({placeholders})
    """, statuses).fetchall()

    if not rows:
        print("No retryable failures found.")
        return

    print(f"Found {len(rows)} file(s) to retry.\n")

    for row in rows:
        repo_folder    = row["download_repository_folder"]
        project_folder = row["download_project_folder"]
        version_folder = row["download_version_folder"]
        file_name      = row["file_name"]

        # Reconstruct local path
        parts = [DATA_ROOT, repo_folder, project_folder]
        if version_folder:
            parts.append(version_folder)
        dest_dir  = pathlib.Path(*parts)
        dest_path = dest_dir / file_name

        # We need to guess the URL. For DataFirst: base + files path.
        # For Dataverse: we stored the file_id in the name (file_{id}).
        # This is best-effort — users may need to fix URLs manually.
        project_url = row["project_url"]

        # Try to infer URL from context
        if "datafirst" in repo_folder:
            # DataFirst public docs are at a guessable URL
            catalog_id = project_folder  # e.g. "940"
            download_url = (
                f"https://www.datafirst.uct.ac.za/dataportal/files/catalog/{catalog_id}/{file_name}"
            )
        elif "dataverse" in repo_folder:
            # Dataverse file IDs are embedded in file names as file_{id}.*
            import re
            m = re.match(r"file_(\d+)", file_name)
            if m:
                file_id = m.group(1)
                download_url = f"https://dataverse.no/api/access/datafile/{file_id}"
            else:
                print(f"  [SKIP] Cannot infer URL for {file_name}")
                continue
        else:
            print(f"  [SKIP] Unknown repo folder: {repo_folder}")
            continue

        print(f"  Retrying: {file_name}")
        print(f"    URL: {download_url}")

        status, size = download_file(download_url, dest_path)
        conn.execute(
            "UPDATE FILES SET status = ? WHERE id = ?",
            (status, row["file_id"]),
        )
        conn.commit()
        print(f"    Result: {status} ({size:,} bytes)\n")

    conn.close()
    print("Retry run complete.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Retry failed file downloads")
    parser.add_argument("--db", default=DB_DEFAULT)
    parser.add_argument(
        "--include-large",
        action="store_true",
        help="Also retry FAILED_TOO_LARGE files",
    )
    args = parser.parse_args()
    retry_failed(args.db, args.include_large)
