"""
scrapers/dataverse_no_scraper.py

Scraper for Dataverse Norway  (https://dataverse.no)

Dataverse exposes a standard REST API — same software as DANS, Harvard Dataverse, etc.
All data access uses the API, so download_method = "API-CALL" throughout.

Key API endpoints:
  Search:       GET /api/search?q={query}&type=dataset&per_page=100&start={offset}
  Metadata:     GET /api/datasets/{persistent_id}  (or by database id)
  File listing: returned inside dataset metadata under .data.latestVersion.files
  File download:GET /api/access/datafile/{file_id}

robots.txt blocks all scraping, so we strictly use the API.
"""

import re
import time
import json
import pathlib
import datetime
import sqlite3
from typing import List, Dict, Any, Optional

import requests

from db.database import (
    upsert_repository, insert_project, insert_file,
    insert_keyword, insert_person, insert_license,
    project_exists,
)
from pipeline.downloader import download_file

BASE_URL    = "https://dataverse.no"
API_SEARCH  = BASE_URL + "/api/search"
API_DATASET = BASE_URL + "/api/datasets/export"
API_ACCESS  = BASE_URL + "/api/access/datafile"
REPO_FOLDER = "dataverse_no"

# Search queries targeting qualitative research / QDA files
QUERIES = [
    "qdpx",
    "qualitative research",
    "interview transcripts",
    "focus group",
    "thematic analysis",
    "nvivo",
    "atlas.ti",
    "qualitative data",
]

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (compatible; SQ26-QDArchive-Seeder/1.0; "
        "FAU Erlangen research project)"
    )
}

SESSION = requests.Session()
SESSION.headers.update(HEADERS)

# Map Dataverse contributor types to professor's enum
CONTRIBUTOR_ROLE_MAP = {
    "author":      "AUTHOR",
    "depositor":   "UPLOADER",
    "distributor": "OWNER",
    "producer":    "OTHER",
    "supervisor":  "OTHER",
    "funder":      "OTHER",
    "editor":      "OTHER",
}


# ── Helpers ───────────────────────────────────────────────────────────────────

def _get(url: str, params: dict = None) -> Optional[requests.Response]:
    try:
        resp = SESSION.get(url, params=params, timeout=30, headers=HEADERS)
        resp.raise_for_status()
        return resp
    except requests.exceptions.HTTPError as e:
        print(f"  [DVno] HTTP {e.response.status_code} for {url}")
        return None
    except Exception as exc:
        print(f"  [DVno] Request error: {exc}")
        return None


def _parse_license(raw: str) -> str:
    """Normalise CC / ODbL license strings. Return original if unrecognised."""
    if not raw:
        return "UNKNOWN"
    r = raw.strip()
    mapping = {
        "cc0":              "CC0",
        "public domain":    "CC0",
        "cc by 4.0":        "CC BY 4.0",
        "cc-by-4.0":        "CC BY 4.0",
        "cc by":            "CC BY",
        "cc-by":            "CC BY",
        "cc by-sa":         "CC BY-SA",
        "cc-by-sa":         "CC BY-SA",
        "cc by-nc":         "CC BY-NC",
        "cc-by-nc":         "CC BY-NC",
        "cc by-nd":         "CC BY-ND",
        "cc-by-nd":         "CC BY-ND",
        "cc by-nc-nd":      "CC BY-NC-ND",
        "cc-by-nc-nd":      "CC BY-NC-ND",
        "odbl":             "ODbL",
        "odc-by":           "ODC-By",
        "pddl":             "PDDL",
    }
    lower = r.lower()
    for key, val in mapping.items():
        if key in lower:
            version = re.search(r"\d+\.\d+", r)
            return f"{val} {version.group()}" if version and val[-1].isalpha() else val
    return r


def _search_datasets(query: str, per_page: int = 100) -> List[Dict]:
    """Return all dataset items matching *query* via Dataverse search API."""
    results = []
    start = 0
    while True:
        resp = _get(API_SEARCH, params={
            "q":        query,
            "type":     "dataset",
            "per_page": per_page,
            "start":    start,
        })
        if resp is None:
            break
        data = resp.json().get("data", {})
        items = data.get("items", [])
        results.extend(items)
        total = data.get("total_count", 0)
        start += per_page
        if start >= total:
            break
        time.sleep(0.5)
    return results


def _fetch_dataset_metadata(global_id: str) -> Optional[Dict]:
    """Fetch full dataset metadata (schema.org / native format)."""
    resp = _get(API_DATASET, params={"exporter": "dataverse_json", "persistentId": global_id})
    if resp is None:
        return None
    try:
        return resp.json()
    except Exception:
        return None


def _extract_field(fields: List[Dict], field_name: str) -> List[str]:
    """Recursively extract all values for a named field in Dataverse metadata."""
    values = []
    for field in fields:
        if field.get("typeName") == field_name:
            val = field.get("value")
            if isinstance(val, str):
                values.append(val)
            elif isinstance(val, list):
                for item in val:
                    if isinstance(item, str):
                        values.append(item)
                    elif isinstance(item, dict):
                        # compound field — recurse
                        values.extend(_extract_field(list(item.values()), field_name))
        if "value" in field and isinstance(field["value"], list):
            for sub in field["value"]:
                if isinstance(sub, dict):
                    values.extend(_extract_field(list(sub.values()), field_name))
    return values


def _compound_field(fields: List[Dict], type_name: str) -> List[Dict]:
    for field in fields:
        if field.get("typeName") == type_name:
            val = field.get("value", [])
            if isinstance(val, list):
                return val
    return []


# ── Main scraper entry point ───────────────────────────────────────────────────

def run(
    conn: sqlite3.Connection,
    data_root: pathlib.Path,
    queries: List[str] = None,
    max_projects: int = 300,
) -> None:
    """
    Query Dataverse Norway, populate the DB, download files.

    Parameters
    ----------
    conn         : open SQLite connection
    data_root    : root data/ folder (files go to data_root/dataverse_no/{doi_suffix}/)
    queries      : list of search strings; defaults to QUERIES
    max_projects : safety cap
    """
    if queries is None:
        queries = QUERIES

    repo_id = upsert_repository(conn, "Dataverse Norway", BASE_URL)
    conn.commit()

    seen_global_ids: set = set()
    processed = 0

    for query in queries:
        print(f"\n[DVno] Query: '{query}'")
        items = _search_datasets(query)
        print(f"  Found {len(items)} dataset results")

        for item in items:
            if processed >= max_projects:
                print("[DVno] Reached max_projects limit, stopping.")
                return

            global_id = item.get("global_id", "")
            if not global_id or global_id in seen_global_ids:
                continue
            seen_global_ids.add(global_id)

            project_url = item.get("url") or f"{BASE_URL}/dataset.xhtml?persistentId={global_id}"

            if project_exists(conn, project_url):
                print(f"  [{global_id}] Already in DB, skipping.")
                continue

            # ── 1. Metadata via API ────────────────────────────────────────
            meta = _fetch_dataset_metadata(global_id)
            if not meta:
                # Fall back to search result fields
                meta = {}

            # Pull fields from either the full metadata or the search snippet
            ds_version = (meta.get("datasetVersion") or
                          meta.get("latestVersion") or {})
            meta_fields: List[Dict] = (
                ds_version.get("metadataBlocks", {})
                          .get("citation", {})
                          .get("fields", [])
            )

            # Title
            title_list = _extract_field(meta_fields, "title")
            title = title_list[0] if title_list else item.get("name", global_id)

            # Description
            desc_list = _extract_field(meta_fields, "dsDescriptionValue")
            description = " ".join(desc_list) if desc_list else item.get("description", "")

            # Language
            lang_list = _extract_field(meta_fields, "language")
            language = lang_list[0] if lang_list else None

            # DOI
            doi = None
            if global_id.startswith("doi:"):
                doi = "https://doi.org/" + global_id[4:]

            # Upload date
            upload_date = (
                ds_version.get("releaseTime") or
                ds_version.get("createTime") or
                item.get("published_at") or
                None
            )
            if upload_date and "T" in str(upload_date):
                upload_date = str(upload_date)[:10]  # keep YYYY-MM-DD

            # Version label
            version_label = str(ds_version.get("versionNumber", "") or "")
            if ds_version.get("versionMinorNumber") is not None:
                version_label += f".{ds_version['versionMinorNumber']}"

            # Project folder: use the DOI suffix (last segment)
            project_folder = re.sub(r"[^\w\-]", "_", global_id.replace("doi:", "").replace("/", "_"))

            download_date = datetime.datetime.utcnow().isoformat(timespec="seconds") + "Z"

            project_id = insert_project(
                conn,
                query_string               = query,
                repository_id              = repo_id,
                repository_url             = BASE_URL,
                project_url                = project_url,
                version                    = version_label or None,
                title                      = title,
                description                = description,
                language                   = language,
                doi                        = doi,
                upload_date                = upload_date,
                download_date              = download_date,
                download_repository_folder = REPO_FOLDER,
                download_project_folder    = project_folder,
                download_version_folder    = None,
                download_method            = "API-CALL",
            )

            # ── 2. Keywords ────────────────────────────────────────────────
            kw_list = _extract_field(meta_fields, "keywordValue")
            # Also pull topic classification
            kw_list += _extract_field(meta_fields, "topicClassValue")
            for kw in kw_list:
                if kw.strip():
                    insert_keyword(conn, project_id, kw.strip())

            # ── 3. Persons ─────────────────────────────────────────────────
            authors = _compound_field(meta_fields, "author")
            for author in authors:
                name_field = author.get("authorName", {})
                name = name_field.get("value", "").strip() if isinstance(name_field, dict) else str(name_field)
                if name:
                    insert_person(conn, project_id, name, "AUTHOR")

            # Depositor / contact
            contacts = _compound_field(meta_fields, "datasetContact")
            for contact in contacts:
                name_field = contact.get("datasetContactName", {})
                name = name_field.get("value", "").strip() if isinstance(name_field, dict) else str(name_field)
                if name:
                    insert_person(conn, project_id, name, "UPLOADER")

            # ── 4. License ─────────────────────────────────────────────────
            license_raw = (
                ds_version.get("license") or
                ds_version.get("termsOfUse") or
                ""
            )
            if isinstance(license_raw, dict):
                license_raw = license_raw.get("name") or license_raw.get("uri") or ""
            insert_license(conn, project_id, _parse_license(str(license_raw)))

            # ── 5. Files ───────────────────────────────────────────────────
            dest_dir = data_root / REPO_FOLDER / project_folder
            dest_dir.mkdir(parents=True, exist_ok=True)

            files = ds_version.get("files", [])
            if not files:
                # Save the raw metadata JSON as the only "file"
                meta_file = dest_dir / "dataset_metadata.json"
                meta_file.write_text(json.dumps(meta, indent=2, ensure_ascii=False))
                insert_file(conn, project_id, "dataset_metadata.json", "json", "SUCCEEDED")
            else:
                # Always save full metadata JSON alongside the actual files
                meta_file = dest_dir / "dataset_metadata.json"
                meta_file.write_text(json.dumps(meta, indent=2, ensure_ascii=False))
                insert_file(conn, project_id, "dataset_metadata.json", "json", "SUCCEEDED")

                for file_info in files:
                    df       = file_info.get("dataFile", {})
                    file_id  = df.get("id")
                    filename = df.get("filename") or df.get("label") or f"file_{file_id}"
                    ext      = pathlib.Path(filename).suffix.lstrip(".").lower() or "bin"
                    size     = df.get("filesize") or 0

                    # Check if restricted
                    restricted = file_info.get("restricted", False)
                    if restricted:
                        insert_file(conn, project_id, filename, ext, "FAILED_LOGIN_REQUIRED")
                        print(f"    {filename}  →  FAILED_LOGIN_REQUIRED (restricted)")
                        continue

                    download_url = f"{API_ACCESS}/{file_id}"
                    dest_path    = dest_dir / filename
                    status, _sz  = download_file(download_url, dest_path)
                    insert_file(conn, project_id, filename, ext, status)
                    print(f"    {filename}  →  {status}")
                    time.sleep(0.3)

            conn.commit()
            processed += 1
            print(f"  [{global_id}] '{title[:60]}' inserted (project_id={project_id})")
            time.sleep(0.8)

    print(f"\n[DVno] Done. Total projects processed: {processed}")
