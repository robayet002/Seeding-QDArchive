"""
scrapers/datafirst_scraper.py

Scraper for DataFirst UCT  (https://www.datafirst.uct.ac.za)

DataFirst runs NADA (National Data Archive), which exposes:
  - Catalog search:  /dataportal/index.php/catalog?sk={query}&page={n}
  - JSON metadata:   /dataportal/index.php/metadata/export/{id}/json
  - File list page:  /dataportal/index.php/catalog/{id}/related-materials
  - Documentation PDF (public): /dataportal/files/catalog/{id}/...

Most microdata requires login → status = FAILED_LOGIN_REQUIRED.
Documentation PDFs, questionnaires and reports are publicly accessible.

Download method classification:
  metadata  → API-CALL   (JSON endpoint)
  files     → SCRAPING   (HTML file-list page → direct URL)
"""

import re
import time
import pathlib
import datetime
import sqlite3
from typing import List, Dict, Any

import requests
from bs4 import BeautifulSoup

from db.database import (
    upsert_repository, insert_project, insert_file,
    insert_keyword, insert_person, insert_license,
    project_exists,
)
from pipeline.downloader import download_file

BASE_URL        = "https://www.datafirst.uct.ac.za"
CATALOG_URL     = BASE_URL + "/dataportal/index.php/catalog"
METADATA_URL    = BASE_URL + "/dataportal/index.php/metadata/export/{id}/json"
MATERIALS_URL   = BASE_URL + "/dataportal/index.php/catalog/{id}/related-materials"
REPO_FOLDER     = "datafirst"

# Queries to run (targeting qualitative / interview studies)
QUERIES = [
    "qualitative",
    "interview",
    "focus group",
    "qualitative research",
    "qdpx",
]

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (compatible; SQ26-QDArchive-Seeder/1.0; "
        "FAU Erlangen research project)"
    )
}

SESSION = requests.Session()
SESSION.headers.update(HEADERS)


# ── Helpers ──────────────────────────────────────────────────────────────────

def _get(url: str, **kwargs) -> requests.Response:
    resp = SESSION.get(url, timeout=30, **kwargs)
    resp.raise_for_status()
    return resp


def _parse_license(raw: str) -> str:
    """Normalise CC license strings. Keep original if unrecognised."""
    if not raw:
        return "UNKNOWN"
    r = raw.strip()
    mapping = {
        "cc-by":        "CC BY",
        "cc by":        "CC BY",
        "attribution":  "CC BY",
        "cc-by-sa":     "CC BY-SA",
        "cc by-sa":     "CC BY-SA",
        "cc-by-nc":     "CC BY-NC",
        "cc by-nc":     "CC BY-NC",
        "cc-by-nd":     "CC BY-ND",
        "cc by-nd":     "CC BY-ND",
        "cc-by-nc-nd":  "CC BY-NC-ND",
        "cc0":          "CC0",
        "public domain": "CC0",
        "odbl":         "ODbL",
        "odc-by":       "ODC-By",
        "pddl":         "PDDL",
    }
    lower = r.lower()
    for key, val in mapping.items():
        if key in lower:
            # Try to preserve version number e.g. "4.0"
            version = re.search(r"\d+\.\d+", r)
            return f"{val} {version.group()}" if version else val
    return r  # keep original per professor's instructions


def _catalog_ids_for_query(query: str, max_pages: int = 10) -> List[int]:
    """Scrape catalog IDs from NADA search results pages."""
    ids = []
    for page in range(1, max_pages + 1):
        try:
            resp = _get(CATALOG_URL, params={"sk": query, "page": page})
        except Exception as exc:
            print(f"  [DataFirst] Page {page} error: {exc}")
            break

        soup = BeautifulSoup(resp.text, "html.parser")

        # Each result card has a link like /catalog/940
        links = soup.select("h5 a[href*='/catalog/']")
        if not links:
            break  # no more results

        for a in links:
            href = a["href"]
            m = re.search(r"/catalog/(\d+)", href)
            if m:
                ids.append(int(m.group(1)))

        time.sleep(1)

    return list(set(ids))


def _fetch_metadata(catalog_id: int) -> Dict[str, Any]:
    """Fetch the JSON metadata for a single catalog entry."""
    url = METADATA_URL.format(id=catalog_id)
    try:
        resp = _get(url)
        return resp.json()
    except Exception as exc:
        print(f"  [DataFirst] Metadata fetch error for {catalog_id}: {exc}")
        return {}


def _list_files(catalog_id: int) -> List[Dict[str, str]]:
    """
    Scrape the related-materials page to discover downloadable files.
    Returns list of dicts: {name, url, type}
    """
    url = MATERIALS_URL.format(id=catalog_id)
    try:
        resp = _get(url)
    except Exception as exc:
        print(f"  [DataFirst] File list error for {catalog_id}: {exc}")
        return []

    soup = BeautifulSoup(resp.text, "html.parser")
    files = []

    for a in soup.select("a[href]"):
        href = a["href"]
        # Only grab direct file links (PDFs, docs, data files)
        if re.search(r"\.(pdf|doc|docx|txt|xlsx|xls|csv|zip|sav|dta|qdpx|nvp|mx24|mqda)$",
                     href, re.IGNORECASE):
            name = pathlib.Path(href).name
            ext  = pathlib.Path(name).suffix.lstrip(".").lower()
            full_url = href if href.startswith("http") else BASE_URL + href
            files.append({"name": name, "url": full_url, "type": ext})

    # Deduplicate by URL
    seen = set()
    unique = []
    for f in files:
        if f["url"] not in seen:
            seen.add(f["url"])
            unique.append(f)

    return unique


# ── Main scraper entry point ──────────────────────────────────────────────────

def run(
    conn: sqlite3.Connection,
    data_root: pathlib.Path,
    queries: List[str] = None,
    max_projects: int = 200,
) -> None:
    """
    Scrape DataFirst, populate the DB, and download files.

    Parameters
    ----------
    conn         : open SQLite connection
    data_root    : root data/ folder (files go to data_root/datafirst/{id}/)
    queries      : list of search strings; defaults to QUERIES
    max_projects : safety cap on how many projects to process
    """
    if queries is None:
        queries = QUERIES

    repo_id = upsert_repository(conn, "DataFirst UCT", BASE_URL)
    conn.commit()

    seen_project_ids: set = set()
    processed = 0

    for query in queries:
        print(f"\n[DataFirst] Query: '{query}'")
        catalog_ids = _catalog_ids_for_query(query)
        print(f"  Found {len(catalog_ids)} catalog entries")

        for cat_id in catalog_ids:
            if processed >= max_projects:
                print("[DataFirst] Reached max_projects limit, stopping.")
                return
            if cat_id in seen_project_ids:
                continue
            seen_project_ids.add(cat_id)

            project_url = f"{CATALOG_URL}/{cat_id}"

            if project_exists(conn, project_url):
                print(f"  [{cat_id}] Already in DB, skipping.")
                continue

            # ── 1. Fetch metadata via API ────────────────────────────────────
            meta = _fetch_metadata(cat_id)
            if not meta:
                continue

            study  = meta.get("study_desc", {})
            title_stmt  = study.get("title_statement", {})
            study_info  = study.get("study_info", {})
            data_access = study.get("data_access", {})
            dataset_use = data_access.get("dataset_use", {})

            title       = title_stmt.get("title") or f"DataFirst-{cat_id}"
            description = study_info.get("abstract") or ""
            version     = study.get("version_statement", {}).get("version") or ""

            # Language — NADA doesn't expose BCP47 cleanly; leave blank
            language = None

            # DOI
            cit = dataset_use.get("cit_req", "")
            doi_match = re.search(r"https?://doi\.org/\S+", cit)
            doi = doi_match.group() if doi_match else None

            # Upload date — use version_date
            upload_date = study.get("version_statement", {}).get("version_date") or None

            # Collection dates — use as fallback
            coll_dates = study_info.get("coll_dates", [])
            if not upload_date and coll_dates:
                upload_date = coll_dates[0].get("start")

            download_date = datetime.datetime.utcnow().isoformat(timespec="seconds") + "Z"
            project_folder = str(cat_id)

            project_id = insert_project(
                conn,
                query_string               = query,
                repository_id              = repo_id,
                repository_url             = BASE_URL,
                project_url                = project_url,
                version                    = version,
                title                      = title,
                description                = description,
                language                   = language,
                doi                        = doi,
                upload_date                = upload_date,
                download_date              = download_date,
                download_repository_folder = REPO_FOLDER,
                download_project_folder    = project_folder,
                download_version_folder    = None,
                download_method            = "API-CALL",
            )

            # ── 2. Keywords ───────────────────────────────────────────────────
            # NADA JSON doesn't expose keywords cleanly; use data_kind + nation
            kw_sources = []
            kw_sources.append(study_info.get("data_kind", ""))
            for nation in study_info.get("nation", []):
                kw_sources.append(nation.get("name", ""))
            for kw in kw_sources:
                if kw:
                    insert_keyword(conn, project_id, kw)

            # ── 3. Persons ────────────────────────────────────────────────────
            for entity in study.get("authoring_entity", []):
                name = entity.get("name", "").strip()
                if name:
                    insert_person(conn, project_id, name, "AUTHOR")

            doc_desc = meta.get("doc_desc", {})
            for producer in doc_desc.get("producers", []):
                name = producer.get("name", "").strip()
                if name:
                    role_raw = producer.get("role", "").lower()
                    if "upload" in role_raw:
                        role = "UPLOADER"
                    elif "metadata" in role_raw or "producer" in role_raw:
                        role = "OTHER"
                    else:
                        role = "UNKNOWN"
                    insert_person(conn, project_id, name, role)

            # ── 4. License ────────────────────────────────────────────────────
            license_raw = dataset_use.get("conditions", "")
            insert_license(conn, project_id, _parse_license(license_raw))

            # ── 5. Files — scrape related-materials page ──────────────────────
            dest_dir = data_root / REPO_FOLDER / project_folder
            dest_dir.mkdir(parents=True, exist_ok=True)

            file_list = _list_files(cat_id)
            if not file_list:
                # Record that there are no public files
                insert_file(conn, project_id,
                            f"catalog_{cat_id}_metadata.json",
                            "json", "SUCCEEDED")
                # Save the raw JSON metadata we already fetched
                import json
                (dest_dir / f"catalog_{cat_id}_metadata.json").write_text(
                    json.dumps(meta, indent=2, ensure_ascii=False)
                )
            else:
                for f in file_list:
                    dest_path = dest_dir / f["name"]
                    status, _size = download_file(f["url"], dest_path)
                    insert_file(conn, project_id, f["name"], f["type"], status)
                    print(f"    {f['name']}  →  {status}")
                    time.sleep(0.5)

            conn.commit()
            processed += 1
            print(f"  [{cat_id}] '{title[:60]}' inserted (project_id={project_id})")
            time.sleep(1)

    print(f"\n[DataFirst] Done. Total projects processed: {processed}")
