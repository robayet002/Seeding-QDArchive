"""
export/export_csv.py
Export every DB table to a CSV file for submission or inspection.
"""

import csv
import sqlite3
import pathlib
import argparse

DB_DEFAULT  = "23277555-seeding.db"
OUT_DEFAULT = "export/csv"

TABLES = ["REPOSITORIES", "PROJECTS", "FILES", "KEYWORDS", "PERSON_ROLE", "LICENSES"]


def export_all(db_path: str = DB_DEFAULT, out_dir: str = OUT_DEFAULT) -> None:
    out = pathlib.Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row

    for table in TABLES:
        rows = conn.execute(f"SELECT * FROM {table}").fetchall()
        if not rows:
            print(f"  {table}: (empty)")
            continue
        outfile = out / f"{table.lower()}.csv"
        with open(outfile, "w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows([dict(r) for r in rows])
        print(f"  {table}: {len(rows)} rows → {outfile}")

    conn.close()
    print(f"\nExport complete → {out}/")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--db",  default=DB_DEFAULT)
    parser.add_argument("--out", default=OUT_DEFAULT)
    args = parser.parse_args()
    export_all(args.db, args.out)
